#include <stdio.h>
#include "part1.h"
#include "lecture.h"
#include "lecture.c"
#include "part1.c"

int main() {
   int choix;
   vol vols[41];
   int result_count;
   int result_count2;
   int result_count3;
   vol vol_concerne[41];
   vol vol_concerne2[41];
   vol vol_concerne3[41];
   lecture(vols, 41);
   printf("MENU\n");
   printf("**********************************************************************\n");
   printf("1-Affichage de la liste des vols\n");
   printf("2-Recherche d'un vol \n");
   printf("3-Affichage de la liste des passager\n");
   printf("4-Reprogramation des retard\n");
   printf("**********************************************************************\n");
   printf("Que voulez vous faire ?\n");
   scanf("%d",&choix);
   if(choix==1){
        tri_insertion(vols, 40);
        int heure_vol_trie;
        printf("A partir de quelle heure ?");
        scanf("%d",&heure_vol_trie);
        affiche_vol(heure_vol_trie,vols,40);

   }


   if(choix==4){
    retard(vols,40);
   }
   if(choix==3){
        int nb_passager;
       printf("Quelle est le nombre de passager pour ce vol");
       scanf("%d",&nb_passager);
       affiche_embarque(vols,nb_passager);}
   if(choix==2){
   int choix0;
   printf("voulez vous faire la recherche par compagnie tapez 1 par horaire tapez 2 par destination tapez3 \n");
   scanf("%d",&choix0);
   if(choix0==1){
   char compagnie[12];
   printf("Quelle compagnie vous cherchez ?\n");
   fflush(stdin);
   fgets (compagnie,sizeof(compagnie), stdin);
    if (compagnie[strlen(compagnie) - 1] == '\n') {
        compagnie[strlen(compagnie) - 1] = '\0';
    }
   result_count=recherche_vol_comp(compagnie, 40, vols, vol_concerne);
   int t = 0;
   while(t< result_count){
        printf("%d\t",vol_concerne[t].numero);
        printf("%s\t",vol_concerne[t].comp);
        printf("%s\t",vol_concerne[t].dest);
        printf("%d\t",vol_concerne[t].num_compt);
        printf("%d\t",vol_concerne[t].heure_deb_enr);
        printf("%d\t",vol_concerne[t].heure_fin_enr);
        printf("%d\t",vol_concerne[t].num_salle);
        printf("%d\t",vol_concerne[t].heure_deb_emb);
        printf("%d\t",vol_concerne[t].heure_fin_emb);
        printf("%d\t",vol_concerne[t].heure_deco);
        printf("%s\t\n",vol_concerne[t].etat);
        t++;
      }
    int choix_recherche;
   printf("Voulez vous affiner la recherche ?\n");
   printf(" -1 Oui \n -2 Non\n");
   scanf("%d",&choix_recherche);
   if(choix_recherche==1){
    int choix_recherche2;
    printf("Avec l'horaire tapez 1 avec la destination tapez 2 \n");
    scanf("%d",&choix_recherche2);
        if(choix_recherche2==1){
                    int horaire;
                    printf("Quelle horaire ? \n");
                    scanf("%d",&horaire);
                    result_count2= recherche_heure(horaire, result_count,vol_concerne,vol_concerne2);
                    int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                    if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec la destination ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            char destination[12];
                            printf("Quelle destinination vous cherchez ?\n");
                            fflush(stdin);
                               fgets (destination,sizeof(destination), stdin);
                                if (destination[strlen(destination) - 1] == '\n') {
                                    destination[strlen(destination) - 1] = '\0';
                                }
                            result_count3= recherche_vol_destination(destination,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

   }
   else{
            if(choix_recherche2==2){
                    char destination[12];
                    printf("Quelle destinination vous cherchez ?\n");
                    fflush(stdin);
                               fgets (destination,sizeof(destination), stdin);
                                if (destination[strlen(destination) - 1] == '\n') {
                                    destination[strlen(destination) - 1] = '\0';
                                }
                    result_count2=recherche_vol_destination(destination,result_count,vol_concerne,vol_concerne2);
                     int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                    if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec l'horaire ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            int horaire;
                            printf("Quelle horaire ? \n");
                            scanf("%d",&horaire);
                            result_count3= recherche_heure(horaire,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

                }
            else{
                printf("error!");
            }
   }
   }
   }
   if(choix0==2){
    int horaire;
    printf("Quelle horaire ? \n");
    scanf("%d",&horaire);
   result_count=recherche_heure(horaire, 40, vols, vol_concerne);
   int t = 0;
   while(t< result_count){
        printf("%d\t",vol_concerne[t].numero);
        printf("%s\t",vol_concerne[t].comp);
        printf("%s\t",vol_concerne[t].dest);
        printf("%d\t",vol_concerne[t].num_compt);
        printf("%d\t",vol_concerne[t].heure_deb_enr);
        printf("%d\t",vol_concerne[t].heure_fin_enr);
        printf("%d\t",vol_concerne[t].num_salle);
        printf("%d\t",vol_concerne[t].heure_deb_emb);
        printf("%d\t",vol_concerne[t].heure_fin_emb);
        printf("%d\t",vol_concerne[t].heure_deco);
        printf("%s\t\n",vol_concerne[t].etat);
        t++;
      }
    int choix_recherche;
   printf("Voulez vous affiner la recherche ?\n");
   printf(" -1 Oui \n -2 Non\n");
   scanf("%d",&choix_recherche);
   if(choix_recherche==1){
    int choix_recherche2;
    printf("Avec la compagnie tapez 1 avec la destination tapez 2 \n");
     char compagnie[12];
    printf("Quelle compagnie vous cherchez ?\n");
    fflush(stdin);
   fgets (compagnie,sizeof(compagnie), stdin);
    if (compagnie[strlen(compagnie) - 1] == '\n') {
        compagnie[strlen(compagnie) - 1] = '\0';
    }
        if(choix_recherche2==1){
                    char compagnie[12];
                    printf("Quelle compagnie vous cherchez ?\n");
                    scanf("%s",&compagnie);
                    result_count2= recherche_vol_comp(compagnie, result_count,vol_concerne,vol_concerne2);
                    int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                    if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec la destination ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            char destination[12];
                            printf("Quelle destinination vous cherchez ?\n");
                            scanf("%s",&destination);
                            result_count3= recherche_vol_destination(destination,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

   }
   else{
            if(choix_recherche2==2){
                    char destination[12];
                    printf("Quelle destinination vous cherchez ?\n");
                    fflush(stdin);
                               fgets (destination,sizeof(destination), stdin);
                                if (destination[strlen(destination) - 1] == '\n') {
                                    destination[strlen(destination) - 1] = '\0';
                                }
                    result_count2=recherche_vol_destination(destination,result_count,vol_concerne,vol_concerne2);
                     int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                    if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec la compagnie ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            char compagnie[12];
                            printf("Quelle compagnie vous cherchez ?\n");
                            fflush(stdin);
                               fgets (compagnie,sizeof(compagnie), stdin);
                                if (compagnie[strlen(compagnie) - 1] == '\n') {
                                    compagnie[strlen(compagnie) - 1] = '\0';
                                }
                            result_count3= recherche_vol_comp(compagnie,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

                }
            else{
                printf("error!");
            }
   }
   }
   }
   if(choix0==3){
        char destination[12];
        printf("Quelle destinination vous cherchez ?\n");
        fflush(stdin);
        fgets (destination,sizeof(destination), stdin);
        if (destination[strlen(destination) - 1] == '\n') {
        destination[strlen(destination) - 1] = '\0';}
   result_count=recherche_vol_destination(destination, 40, vols, vol_concerne);
   int t = 0;
   while(t< result_count){
        printf("%d\t",vol_concerne[t].numero);
        printf("%s\t",vol_concerne[t].comp);
        printf("%s\t",vol_concerne[t].dest);
        printf("%d\t",vol_concerne[t].num_compt);
        printf("%d\t",vol_concerne[t].heure_deb_enr);
        printf("%d\t",vol_concerne[t].heure_fin_enr);
        printf("%d\t",vol_concerne[t].num_salle);
        printf("%d\t",vol_concerne[t].heure_deb_emb);
        printf("%d\t",vol_concerne[t].heure_fin_emb);
        printf("%d\t",vol_concerne[t].heure_deco);
        printf("%s\t\n",vol_concerne[t].etat);
        t++;
      }
    int choix_recherche;
   printf("Voulez vous affiner la recherche ?\n");
   printf(" -1 Oui \n -2 Non\n");
   scanf("%d",&choix_recherche);
   if(choix_recherche==1){
    int choix_recherche2;
    printf("Avec l'horaire tapez 1 avec la compagnie tapez 2 \n");
    scanf("%d",&choix_recherche2);
        if(choix_recherche2==1){
                    int horaire;
                    printf("Quelle horaire ? \n");
                    scanf("%d",&horaire);
                    result_count2= recherche_heure(horaire, result_count,vol_concerne,vol_concerne2);
                    int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                     if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec la compagnie ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            char compagnie[12];
                            printf("Quelle compagnie vous cherchez ?\n");
                            fflush(stdin);
                               fgets (compagnie,sizeof(compagnie), stdin);
                                if (compagnie[strlen(compagnie) - 1] == '\n') {
                                    compagnie[strlen(compagnie) - 1] = '\0';
                                }
                            result_count3= recherche_vol_comp(compagnie,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

   }
   else{
            if(choix_recherche2==2){
                    char compagnie[12];
                    printf("Quelle compagnie vous cherchez ?\n");
                    fflush(stdin);
                           fgets (compagnie,sizeof(compagnie), stdin);
                            if (compagnie[strlen(compagnie) - 1] == '\n') {
                                compagnie[strlen(compagnie) - 1] = '\0';}
                    result_count2= recherche_vol_comp(compagnie, result_count,vol_concerne,vol_concerne2);
                    int k = 0;
                     while(k< result_count2){
                        printf("%d\t",vol_concerne2[k].numero);
                        printf("%s\t",vol_concerne2[k].comp);
                        printf("%s\t",vol_concerne2[k].dest);
                        printf("%d\t",vol_concerne2[k].num_compt);
                        printf("%d\t",vol_concerne2[k].heure_deb_enr);
                        printf("%d\t",vol_concerne2[k].heure_fin_enr);
                        printf("%d\t",vol_concerne2[k].num_salle);
                        printf("%d\t",vol_concerne2[k].heure_deb_emb);
                        printf("%d\t",vol_concerne2[k].heure_fin_emb);
                        printf("%d\t",vol_concerne2[k].heure_deco);
                        printf("%s\t\n",vol_concerne2[k].etat);
                        k++;
                    }
                    if(result_count2>=2){
                        int choix_recherche3;
                        printf("Voulez vous affiner la recherche avec l'horaire ?\n");
                        printf(" -1 Oui \n -2 Non\n");
                        scanf("%d",&choix_recherche3);
                        if(choix_recherche3==1){
                            int horaire;
                            printf("Quelle horaire ? \n");
                            scanf("%d",&horaire);
                            result_count3= recherche_heure(horaire,result_count2,vol_concerne2,vol_concerne3);
                            int r = 0;
                            while(r< result_count3){
                                printf("%d\t",vol_concerne2[r].numero);
                                printf("%s\t",vol_concerne2[r].comp);
                                printf("%s\t",vol_concerne2[r].dest);
                                printf("%d\t",vol_concerne2[r].num_compt);
                                printf("%d\t",vol_concerne2[r].heure_deb_enr);
                                printf("%d\t",vol_concerne2[r].heure_fin_enr);
                                printf("%d\t",vol_concerne2[r].num_salle);
                                printf("%d\t",vol_concerne2[r].heure_deb_emb);
                                printf("%d\t",vol_concerne2[r].heure_fin_emb);
                                printf("%d\t",vol_concerne2[r].heure_deco);
                                printf("%s\t\n",vol_concerne2[r].etat);
                                r++;}
                        }
                    }

                }
            else{
                printf("error!");
            }
   }
   }
   }
   }
   return 0;
}
