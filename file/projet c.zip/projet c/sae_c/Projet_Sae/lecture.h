
#pragma once
int lecture(vol* vols, int nb_vols);
void substring(char myline[], char passengersToken[]);
int compteur(char passengersToken[]);
void substring2(char passengersToken[], int k,int cpt,char passengersInfo[]);
